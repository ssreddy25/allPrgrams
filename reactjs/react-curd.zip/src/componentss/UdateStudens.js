import React from 'react'
import StudentList from './StudentList'

function UdateStudens() {
  return (
    <div>
      <StudentList/>
    </div>
  )
}

export default UdateStudens
